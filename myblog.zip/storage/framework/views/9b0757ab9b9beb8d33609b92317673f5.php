
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <h5 class="card-title">Users List</h5>
      <a href="<?php echo e(url('dashboard/users/add')); ?>" style="float: right; margin-top:-30px" class="btn btn-primary">Add User</a>

      <!-- Table with stripped rows -->
      <?php if(session('success')): ?>

       <div class="alert alert-success">
          <?php echo e(session('success')); ?>


       </div>

      <?php endif; ?>
      <table class="table table-striped">
        <thead>
         
              
          
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Created_at</th>
            <th scope="col">Updated_at</th>
            
          </tr>
          
        </thead>
        <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($user->id); ?></th>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->created_at); ?></td>
            <td><?php echo e($user->updated_at); ?></td>
            <td>
              <a href="<?php echo e(url('dashboard/users/edit/'.$user->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
              <form action="<?php echo e(route('destory.users', $user->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this user?');" style="display: inline-block;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger btn-sm">
                    DELETE
                </button>
            </form>
              

              
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>
      <?php echo e($users->links('pagination::bootstrap-5')); ?>

      <!-- End Table with stripped rows -->

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>




  

    

  




<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myblog\resources\views/dashboard/users/list.blade.php ENDPATH**/ ?>