<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>KidKinder - Kindergarten Website </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="<?php echo e(asset("res/img/favicon.ico")); ?>"rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Handlee&family=Nunito&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Flaticon Font -->
    <link href="<?php echo e(asset("res/lib/flaticon/font/flaticon.css")); ?>" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(asset("res/lib/owlcarousel/assets/owl.carousel.min.css")); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("res/lib/lightbox/css/lightbox.min.css")); ?>" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(asset("res/css/style.css")); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>

    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>













 <!-- Back to Top -->
<a href="#" class="btn btn-primary p-3 back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset("res/lib/easing/easing.min.js")); ?>"></script>
<script src="<?php echo e(asset("res/lib/owlcarousel/owl.carousel.min.js")); ?>"></script>
<script src="<?php echo e(asset("res/lib/isotope/isotope.pkgd.min.js")); ?>"></script>
<script src="<?php echo e(asset("res/lib/lightbox/js/lightbox.min.js")); ?>"></script>

    
    

    <!-- Template Javascript -->
<script src="<?php echo e(asset("res/js/main.js")); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>
</body>

</html>




<?php /**PATH C:\xampp\htdocs\myblog\resources\views/layouts/app.blade.php ENDPATH**/ ?>