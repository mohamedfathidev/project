
<?php $__env->startSection('style'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <h5 class="card-title">blogs List</h5>
      <a href="<?php echo e(url('dashboard/blogs/add')); ?>" style="float: right; margin-top:-30px" class="btn btn-primary">Add blog</a>

      <!-- Table with stripped rows -->
      <?php if(session('success')): ?>

       <div class="alert alert-success">
          <?php echo e(session('success')); ?>


       </div>

      <?php endif; ?>
      <table class="table table-striped">
        <thead>
         
              
          
          <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            
            <th scope="col">Image</th>
            <th>Tags</th>
            <th scope="col">Author</th>
            <th scope="col">Author description</th>
            <th scope="col">Created_at</th>
            <th scope="col">Actions</th>
          
            
          </tr>
          
        </thead>
        <tbody>
            
          <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
          <tr>
            <th scope="row"><?php echo e($blog->id); ?></th>
            <td><?php echo e($blog->title); ?></td>
           
            <td><img src="<?php echo e(asset($blog->image)); ?>" alt="" width="75" height="75"></td>
            <td><?php echo e($blog->tags); ?></td>
            <td><?php echo e($blog->Author); ?></td>
            <td><?php echo e($blog->Author_des); ?></td>
            <td><?php echo e($blog->created_at); ?></td>
            
            <td>
              <a href="<?php echo e(url('dashboard/blogs/edit/'.$blog->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
              <form action="<?php echo e(route('destory.blogs', $blog->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this blog?');" style="display: inline-block;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger btn-sm">
                    DELETE
                </button>
            </form>
              

              
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>
      
      <!-- End Table with stripped rows -->

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>




  

    

  




<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myblog\resources\views/dashboard/blogs/list.blade.php ENDPATH**/ ?>