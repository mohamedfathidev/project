
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Detail Start -->
<div class="container py-5">
    <div class="row pt-5">
        <div class="col-lg-8">
            <div class="d-flex flex-column text-left mb-3">
                <p class="section-title pr-5"><span class="pr-2">Blog Detail Page</span></p>
                <h1 class="mb-3"><?php echo e($blog->title); ?></h1>
                <div class="d-flex">
                    <p class="mr-3"><i class="fa fa-user text-primary"></i> <?php echo e($blog->Author); ?></p>
                    
                </div>
            </div>
            <div class="mb-5">
                <img class="img-fluid rounded w-100 mb-4" src="<?php echo e(asset($blog->image)); ?>" style="height:400px;width:600px;object-fit:cover" alt="Image">
                <?php echo $blog->description; ?>

            </div>

            

          
        </div>

        <div class="col-lg-4 mt-5 mt-lg-0">
            <!-- Author Bio -->
            <div class="d-flex flex-column text-center bg-primary rounded mb-5 py-5 px-4">
                <img src="<?php echo e(asset($blog->image)); ?>" class="img-fluid rounded-circle mx-auto mb-3" style="width: 100px;">
                <h3 class="text-secondary mb-3"><?php echo e($blog->Author); ?></h3>
                <p class="text-white m-0"><?php echo e($blog->Author_des); ?></p>
            </div>

           

           

            <!-- Tag Cloud -->
            <div class="mb-5">
                
                <h2 class="mb-4">Tag Cloud</h2>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex flex-wrap m-n1">
                    <a href="" class="btn btn-outline-primary m-1"><?php echo e($tag); ?></a>
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

           
        </div>
    </div>
</div>
<!-- Detail End -->
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myblog\resources\views/blog-details.blade.php ENDPATH**/ ?>