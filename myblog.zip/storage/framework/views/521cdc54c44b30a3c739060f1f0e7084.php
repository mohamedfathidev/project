<?php $__env->startComponent('mail::message'); ?>

<p>Hello from myblog website <?php echo e($user->name); ?></p>
    
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\myblog\resources\views/emails/register.blade.php ENDPATH**/ ?>