@component('mail::message')

<p>Hello from myblog website {{$user->name}}</p>
    
@endcomponent